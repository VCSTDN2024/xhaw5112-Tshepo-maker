document.getElementById("nextPageBtn").addEventListener("click", function() {
    window.location.href = "Courses.html"; 
})

document.getElementById("MonthBtn").addEventListener("click", function() {
    window.location.href = "Courses.html"; 
})

document.getElementById("enrollnow").addEventListener("click", function() {
    window.location.href = "Contact Us.html"; 

});