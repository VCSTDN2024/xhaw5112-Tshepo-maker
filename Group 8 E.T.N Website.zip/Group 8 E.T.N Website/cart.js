function updateCart() {
    let totalPrice = 0;
    const discountRate = 0.15; 
    const checkboxes = document.querySelectorAll('.product-checkbox');
  
    
    checkboxes.forEach((checkbox) => {
      if (checkbox.checked) {
        totalPrice += parseFloat(checkbox.getAttribute('data-price'));
      }
    });
  
   
    const discount = totalPrice * discountRate;
    const finalPrice = totalPrice - discount;
  
 
    document.getElementById('total-price').textContent = totalPrice.toFixed(2);
    document.getElementById('discount').textContent = discount.toFixed(2);
    document.getElementById('final-price').textContent = finalPrice.toFixed(2);
  }
  
 
  const checkboxes = document.querySelectorAll('.product-checkbox');
  checkboxes.forEach((checkbox) => {
    checkbox.addEventListener('change', updateCart);
  });